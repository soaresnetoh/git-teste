#!/bin/bash
sudo yum install httpd -y
sudo systemctl start httpd.service
sudo systemctl enable httpd.service
sudo yum install php php-mysql php-common -y
sudo systemctl restart httpd.service
sudo yum install -y aws-cli ruby wget
sudo yum install -y mysql
wget https://aws-codedeploy-us-east-1.s3.us-east-1.amazonaws.com/latest/install
chmod +x ./install
sudo ./install auto
sudo service codedeploy-agent start
sudo chmod 777 /etc/init.d/codedeploy-agent
sudo wget http://pages.cloudtreinamentos.com/aws/arquivos/aplicacao.zip
sudo unzip -o aplicacao.zip -d /var/www/html/
sudo chmod -R 777 /var/www/html
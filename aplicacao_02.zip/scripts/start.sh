#!/bin/bash
cd /var/www/html
rm -R *
